/* This file is generated, all changes will be lost */
#ifndef ___XFPM_DBUS_MARSHAL_MARSHAL_H__
#define ___XFPM_DBUS_MARSHAL_MARSHAL_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* VOID:STRING,BOOLEAN (xfpm-dbus-marshal.list:1) */
extern
void _xfpm_dbus_marshal_VOID__STRING_BOOLEAN (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

/* VOID:STRING,BOOLEAN,BOOLEAN (xfpm-dbus-marshal.list:2) */
extern
void _xfpm_dbus_marshal_VOID__STRING_BOOLEAN_BOOLEAN (GClosure     *closure,
                                                      GValue       *return_value,
                                                      guint         n_param_values,
                                                      const GValue *param_values,
                                                      gpointer      invocation_hint,
                                                      gpointer      marshal_data);


G_END_DECLS

#endif /* ___XFPM_DBUS_MARSHAL_MARSHAL_H__ */
